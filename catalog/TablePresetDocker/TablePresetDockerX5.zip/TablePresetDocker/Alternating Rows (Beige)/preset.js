app.GMSManager.RunMacro("TablePresetDocker", "Macros.AlternatingRows", table, true, app.CreateColor("CMYK100,USER,35,39,48,0,0"), true, app.CreateColor("CMYK100,USER,19,22,26,0,0"));
app.GMSManager.RunMacro("TablePresetDocker", "Macros.SetOutlines", table, true, 1, app.CreateColor("CMYK100,USER,0,0,0,128,0"),true, 2, app.CreateColor("CMYK100,USER,0,0,0,128,0"));
