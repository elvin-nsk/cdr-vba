app.GMSManager.RunMacro("TablePresetDocker", "Macros.SolidColor", table, false, app.CreateColor("CMYK100,USER,7,12,84,0,0"));
app.GMSManager.RunMacro("TablePresetDocker", "Macros.Set3dOutlines", table, true, 1, app.CreateColor("CMYK100,USER,0,0,0,0,0"),true, 1, app.CreateColor("CMYK100,USER,164,115,33,0,0"),true, app.CreateColor("CMYK100,USER,36,15,17,0,0"), false, 3);
