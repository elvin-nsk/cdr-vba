app.GMSManager.RunMacro("TablePresetDocker", "Macros.SolidColor", table, true, app.CreateColor("CMYK100,USER,85,71,70,1,0"));
app.GMSManager.RunMacro("TablePresetDocker", "Macros.Set3dOutlines", table, true, 1, app.CreateColor("CMYK100,USER,28,21,21,0,0"),true, 1, app.CreateColor("CMYK100,USER,145,119,119,11,0"),true, app.CreateColor("CMYK,USER,0,0,0,100,0"), false, 1);
