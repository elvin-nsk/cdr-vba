app.GMSManager.RunMacro("TablePresetDocker", "Macros.SolidColor", table, false, app.CreateColor("CMYK,USER,0,0,0,0,0"));
app.GMSManager.RunMacro("TablePresetDocker", "Macros.SetOutlines", table, true, 1, app.CreateColor("CMYK100,USER,0,0,0,255,0"),true, 3, app.CreateColor("CMYK100,USER,0,0,0,255,0"));
